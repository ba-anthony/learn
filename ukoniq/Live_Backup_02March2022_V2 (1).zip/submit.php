<?php
require __DIR__ . '/../app/submit.php';
