
(function ($) {
    'use strict';


    jQuery(document).ready(function ($) {
        $("#modalOverlay .buttonStyle").on('click', function () {
            $("#modalOverlay").css("display", "none");
        });

        $(".modal .modal-header span.close").on('click', function () {
            $("#myModal1").css("display", "none");
        });
        $(".navbar-toggler").on('click', function () {
            if($( ".nav-logo-menu" ).hasClass( "active" )){
                $(".nav-logo-menu").removeClass("active");
            }else{
                $(".nav-logo-menu").addClass("active");
            }
        });
    });

})(jQuery);
